---
title: Barracuda Above-Water Tracker
emoji: 🏊
colorFrom: blue
colorTo: indigo
sdk: streamlit
sdk_version: "1.32.0"
app_file: app.py
pinned: false
---

# Barracuda Above-Water Tracker (Web App)

Upload an above-water synchronized swimming video and get back an annotated
video + tracking-data CSV, powered by RTMPose-x pose detection.

## Files

- `app.py` — Streamlit UI (upload, settings, progress, download)
- `tracker_core.py` — the tracking engine (tent masking, waterline detection,
  swimmer locking, smoothing, Kalman filtering)
- `requirements.txt` — Python dependencies

## Deploy to Hugging Face Spaces (recommended — free)

1. Go to https://huggingface.co/new-space
2. Name your Space (e.g. `barracuda-tracker`)
3. **SDK**: choose **Streamlit**
4. **Hardware**: leave as the free "CPU basic" tier
5. **Visibility**: Public (so anyone with the link can use it)
6. Click "Create Space"
7. On the new Space page, click "Files" → "Add file" → "Upload files"
   and upload all three files in this folder (`app.py`, `tracker_core.py`,
   `requirements.txt`) — or push them via git:

   ```bash
   git clone https://huggingface.co/spaces/YOUR_USERNAME/barracuda-tracker
   cp app.py tracker_core.py requirements.txt barracuda-tracker/
   cd barracuda-tracker
   git add .
   git commit -m "Initial app"
   git push
   ```

8. The Space will build automatically (installing dependencies takes a few
   minutes the first time — RTMPose model files also download on first use).
9. Once built, your app is live at:
   `https://huggingface.co/spaces/YOUR_USERNAME/barracuda-tracker`

That URL is what you share with anyone who needs to use the tracker.

## Notes on the free tier

- **Hardware**: 2 vCPU, 16GB RAM, 50GB (non-persistent) disk — no cost.
- **Sleep**: free Spaces go to sleep after 48 hours of no traffic and wake up
  automatically (with a ~30s cold start) on the next visit.
- **Speed**: this is CPU-only inference. The app defaults to "Balanced" mode
  for reasonable processing times; "Most Accurate" mode is available in the
  sidebar but will be noticeably slower per video.
- **Concurrent users**: the free tier shares 2 vCPUs across all visitors —
  if a few people process videos at the same time, it'll slow down for
  everyone. If this app gets real traffic, consider upgrading the Space's
  hardware tier (paid, pay-per-hour) from the Space's Settings page.

## Running locally first (recommended before deploying)

```bash
pip install -r requirements.txt
streamlit run app.py
```

This opens the same app at `http://localhost:8501` so you can test it before
putting it online.
